"""
download_usda_food_access_atlas.py

Downloads the USDA ERS Food Access Research Atlas (2019) file (XLSX or ZIP)
into a local folder (no project-folder assumptions).

Source page (ERS):
  https://www.ers.usda.gov/data-products/food-access-research-atlas/download-the-data

Usage:
  python download_usda_food_access_atlas.py --outdir .
  python download_usda_food_access_atlas.py --outdir ./data --format xlsx
  python download_usda_food_access_atlas.py --outdir ./data --format zip

Notes:
  - Uses only Python stdlib (no pip installs).
  - Handles large downloads with streaming + progress.
"""
import argparse
import os
import sys
import time
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

USDA_URLS = {
    "xlsx": "https://www.ers.usda.gov/media/5626/food-access-research-atlas-data-download-2019.xlsx?v=77780",
    "zip":  "https://www.ers.usda.gov/media/5627/food-access-research-atlas-data-download-2019.zip?v=84188",
}

def human_mb(n: int) -> str:
    return f"{n/1024/1024:.2f} MB"

def download(url: str, dest_path: str, chunk_size: int = 1024 * 1024) -> None:
    os.makedirs(os.path.dirname(dest_path) or ".", exist_ok=True)
    req = Request(url, headers={"User-Agent": "Mozilla/5.0"})
    try:
        with urlopen(req, timeout=180) as resp:
            total = resp.headers.get("Content-Length")
            total = int(total) if total and str(total).isdigit() else None

            tmp = dest_path + ".part"
            written = 0
            t0 = time.time()

            with open(tmp, "wb") as f:
                while True:
                    chunk = resp.read(chunk_size)
                    if not chunk:
                        break
                    f.write(chunk)
                    written += len(chunk)

                    if total:
                        pct = 100.0 * written / total
                        sys.stdout.write(f"\r⬇️  {pct:6.2f}%  ({human_mb(written)} / {human_mb(total)})")
                    else:
                        sys.stdout.write(f"\r⬇️  {human_mb(written)} downloaded")
                    sys.stdout.flush()

            dt = max(time.time() - t0, 1e-6)
            sys.stdout.write(f"\n✅ Done in {dt:.1f}s. Saved: {dest_path}\n")
            sys.stdout.flush()
            os.replace(tmp, dest_path)

    except HTTPError as e:
        raise SystemExit(f"❌ HTTP error {e.code}: {e.reason}")
    except URLError as e:
        raise SystemExit(f"❌ Network error: {e}")
    except Exception as e:
        raise SystemExit(f"❌ Unexpected error: {e}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default=".", help="Output directory")
    ap.add_argument("--format", choices=["xlsx", "zip"], default="xlsx", help="Download format")
    ap.add_argument("--filename", default=None, help="Optional override output filename")
    args = ap.parse_args()

    url = USDA_URLS[args.format]
    fname = args.filename or os.path.basename(url.split("?")[0])
    dest = os.path.join(args.outdir, fname)

    print(f"🟦 Downloading USDA Food Access Research Atlas 2019 ({args.format})")
    print(f"🟦 URL: {url}")
    print(f"🟦 Output: {os.path.abspath(dest)}")

    download(url, dest)

if __name__ == "__main__":
    main()
