USDA + CDC PLACES Download Pack

Files
-----
1) download_usda_food_access_atlas.py
   - Standalone downloader for the USDA ERS Food Access Research Atlas (2019) XLSX or ZIP.
   - No project-folder assumptions.

2) PLACES_manual_download_note.txt
   - Documents that PLACES was downloaded manually and includes the official dataset link
     + a mirror link for large-file download.

How to use (USDA)
-----------------
  python download_usda_food_access_atlas.py --outdir . --format xlsx
