#!/usr/bin/env python3
"""
Generate the remaining descriptive-statistics tables and figures for the Mini-PhD writeup.

Expected inputs in the same folder (or edit the paths below):
- PLACES__Local_Data_for_Better_Health,_Census_Tract_Data,_2025_release_20260320_part1.csv
- PLACES__Local_Data_for_Better_Health,_Census_Tract_Data,_2025_release_20260320_part2.csv
- PLACES__Local_Data_for_Better_Health,_Census_Tract_Data,_2025_release_20260320_part3.csv
- australia_lga_analysis_ready.csv

Outputs:
- table1_descriptive_stats.csv
- table2_australia_quality_missingness.csv
- figure1_us_obesity_distribution.png
- figure1_us_obesity_distribution_data.csv
- figure2_au_obesity_distribution.png
- figure2_au_obesity_distribution_data.csv
- figure3_au_obesity_vs_no_vehicle.png
- figure3_au_obesity_vs_no_vehicle_data.csv
- figure4_au_obesity_vs_irsd.png
- figure4_au_obesity_vs_irsd_data.csv
"""

from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# -------------------------
# Edit these paths if needed
# -------------------------
WORKDIR = Path(__file__).resolve().parent
CDC_PARTS = [
    WORKDIR / "PLACES__Local_Data_for_Better_Health,_Census_Tract_Data,_2025_release_20260320_part1.csv",
    WORKDIR / "PLACES__Local_Data_for_Better_Health,_Census_Tract_Data,_2025_release_20260320_part2.csv",
    WORKDIR / "PLACES__Local_Data_for_Better_Health,_Census_Tract_Data,_2025_release_20260320_part3.csv",
]
AU_FILE = WORKDIR / "australia_lga_analysis_ready.csv"


def require_file(path: Path) -> None:
    if not path.exists():
        raise FileNotFoundError(f"Required file not found: {path}")


def load_cdc_obesity(parts: list[Path]) -> pd.DataFrame:
    frames = []
    for p in parts:
        require_file(p)
        df = pd.read_csv(p, low_memory=False)
        frames.append(df)
    cdc = pd.concat(frames, ignore_index=True)

    # Normalize columns just in case
    cdc.columns = [str(c).strip() for c in cdc.columns]

    # Keep adult obesity rows only
    obesity = cdc.loc[
        cdc["Measure"].astype(str).str.strip().eq("Obesity among adults")
    ].copy()

    # Normalize tract GEOID
    obesity["GEOID"] = obesity["LocationID"].astype(str).str.zfill(11)
    obesity["adult_obesity_pct"] = pd.to_numeric(obesity["Data_Value"], errors="coerce")

    obesity = obesity.dropna(subset=["adult_obesity_pct"])
    obesity = obesity.drop_duplicates(subset=["GEOID"])
    return obesity[["GEOID", "adult_obesity_pct"]]


def load_au_file(path: Path) -> pd.DataFrame:
    require_file(path)
    au = pd.read_csv(path, low_memory=False)
    au.columns = [str(c).strip() for c in au.columns]

    # Replace placeholder strings with missing
    au = au.replace({"..": np.nan, "": np.nan})

    # Drop placeholder unknown rows if present
    if "lga_name" in au.columns:
        au = au.loc[~au["lga_name"].astype(str).str.startswith("Unknown", na=False)].copy()

    # Coerce key columns
    for col in ["adult_obesity_asr_per_100", "pct_no_motor_vehicle", "irsd_score"]:
        if col in au.columns:
            au[col] = pd.to_numeric(au[col], errors="coerce")

    return au


def describe_series(country: str, variable: str, s: pd.Series) -> dict:
    s = pd.to_numeric(s, errors="coerce").dropna()
    return {
        "Country": country,
        "Variable": variable,
        "N": int(s.shape[0]),
        "Mean": round(float(s.mean()), 2),
        "SD": round(float(s.std(ddof=1)), 2),
        "Min": round(float(s.min()), 2),
        "Median": round(float(s.median()), 2),
        "Max": round(float(s.max()), 2),
    }


def build_table1(cdc_obesity: pd.DataFrame, au: pd.DataFrame) -> pd.DataFrame:
    rows = []
    rows.append(
        describe_series("United States", "Adult obesity prevalence (%)", cdc_obesity["adult_obesity_pct"])
    )
    rows.append(
        describe_series("Australia", "Adult obesity (ASR per 100)", au["adult_obesity_asr_per_100"])
    )
    rows.append(
        describe_series("Australia", "Dwellings with no motor vehicle (%)", au["pct_no_motor_vehicle"])
    )
    rows.append(
        describe_series("Australia", "IRSD score", au["irsd_score"])
    )
    return pd.DataFrame(rows)


def build_table2(au: pd.DataFrame) -> pd.DataFrame:
    if "quality_indicator" not in au.columns:
        raise KeyError("Expected column 'quality_indicator' not found in Australia file.")

    tmp = au.copy()
    tmp["obesity_missing"] = tmp["adult_obesity_asr_per_100"].isna()

    grp = (
        tmp.groupby("quality_indicator", dropna=False)
        .agg(
            LGAs=("quality_indicator", "size"),
            non_missing_obesity=("obesity_missing", lambda x: int((~x).sum())),
            missing_obesity=("obesity_missing", lambda x: int(x.sum())),
        )
        .reset_index()
        .rename(columns={"quality_indicator": "Quality indicator"})
    )
    grp["Missing rate (%)"] = (grp["missing_obesity"] / grp["LGAs"] * 100).round(1)
    grp = grp.rename(
        columns={
            "non_missing_obesity": "Non-missing obesity",
            "missing_obesity": "Missing obesity",
        }
    )

    preferred_order = ["Good", "Acceptable", "Poor"]
    grp["order"] = grp["Quality indicator"].map({k: i for i, k in enumerate(preferred_order)})
    grp = grp.sort_values(["order", "Quality indicator"]).drop(columns=["order"])
    return grp


def save_histogram(data: pd.Series, title: str, xlabel: str, fig_path: Path, data_path: Path) -> None:
    s = pd.to_numeric(data, errors="coerce").dropna()
    pd.DataFrame({"value": s}).to_csv(data_path, index=False)

    plt.figure(figsize=(8, 5))
    plt.hist(s, bins=30)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(fig_path, dpi=200)
    plt.close()


def save_scatter(x: pd.Series, y: pd.Series, title: str, xlabel: str, ylabel: str, fig_path: Path, data_path: Path) -> None:
    plot_df = pd.DataFrame({"x": pd.to_numeric(x, errors="coerce"), "y": pd.to_numeric(y, errors="coerce")}).dropna()
    plot_df.to_csv(data_path, index=False)

    plt.figure(figsize=(7, 5))
    plt.scatter(plot_df["x"], plot_df["y"], alpha=0.6)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.tight_layout()
    plt.savefig(fig_path, dpi=200)
    plt.close()


def main() -> None:
    cdc_obesity = load_cdc_obesity(CDC_PARTS)
    au = load_au_file(AU_FILE)

    table1 = build_table1(cdc_obesity, au)
    table2 = build_table2(au)

    table1.to_csv(WORKDIR / "table1_descriptive_stats.csv", index=False)
    table2.to_csv(WORKDIR / "table2_australia_quality_missingness.csv", index=False)

    save_histogram(
        cdc_obesity["adult_obesity_pct"],
        "United States adult obesity distribution",
        "Adult obesity prevalence (%)",
        WORKDIR / "figure1_us_obesity_distribution.png",
        WORKDIR / "figure1_us_obesity_distribution_data.csv",
    )

    save_histogram(
        au["adult_obesity_asr_per_100"],
        "Australia adult obesity distribution",
        "Adult obesity (ASR per 100)",
        WORKDIR / "figure2_au_obesity_distribution.png",
        WORKDIR / "figure2_au_obesity_distribution_data.csv",
    )

    save_scatter(
        au["pct_no_motor_vehicle"],
        au["adult_obesity_asr_per_100"],
        "Australia obesity and transport friction",
        "Dwellings with no motor vehicle (%)",
        "Adult obesity (ASR per 100)",
        WORKDIR / "figure3_au_obesity_vs_no_vehicle.png",
        WORKDIR / "figure3_au_obesity_vs_no_vehicle_data.csv",
    )

    save_scatter(
        au["irsd_score"],
        au["adult_obesity_asr_per_100"],
        "Australia obesity and deprivation",
        "IRSD score",
        "Adult obesity (ASR per 100)",
        WORKDIR / "figure4_au_obesity_vs_irsd.png",
        WORKDIR / "figure4_au_obesity_vs_irsd_data.csv",
    )

    print("Done.")
    print(f"CDC obesity sample size: {cdc_obesity.shape[0]}")
    print(f"Australia LGA rows after cleaning: {au.shape[0]}")
    print("Wrote:")
    for name in [
        "table1_descriptive_stats.csv",
        "table2_australia_quality_missingness.csv",
        "figure1_us_obesity_distribution.png",
        "figure1_us_obesity_distribution_data.csv",
        "figure2_au_obesity_distribution.png",
        "figure2_au_obesity_distribution_data.csv",
        "figure3_au_obesity_vs_no_vehicle.png",
        "figure3_au_obesity_vs_no_vehicle_data.csv",
        "figure4_au_obesity_vs_irsd.png",
        "figure4_au_obesity_vs_irsd_data.csv",
    ]:
        print(" -", name)


if __name__ == "__main__":
    main()
