r"""
acs_pull_model4_full_controls.py

Model 4: baseline USDA distance-only access + effective-access index + remaining controls.
ACS side: pull Model 2/3 friction variables PLUS optional total population (B01003_001E).

- Downloads ACS 5-year tract data US-wide (state-by-state)
- Writes ONE CSV + manifest
- Computes derived rates

Run:
  set CENSUS_API_KEY=YOUR_KEY_HERE
  py acs_pull_model4_full_controls.py --year 2022

Outputs:
  ACS_Model4_FullControls_<YEAR>.csv
  ACS_Model4_FullControls_<YEAR>__manifest.json
"""


from __future__ import annotations

import argparse
import csv
import json
import os
import time
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

SENTINELS = {"-666666666", "-888888888", "-999999999", ""}

def info(msg: str) -> None:
    print(f"🟦 {msg}")

def ok(msg: str) -> None:
    print(f"✅ {msg}")

def warn(msg: str) -> None:
    print(f"⚠️ {msg}")

def die(msg: str, code: int = 1) -> None:
    print(f"❌ {msg}")
    raise SystemExit(code)

def _is_retryable_http(code: int) -> bool:
    return code == 429 or 500 <= code <= 599

def fetch_json_with_retries(url: str, timeout: int = 180, max_retries: int = 6, base_sleep: float = 0.8) -> list:
    """Fetch JSON from Census API with retry/backoff on 429/5xx/timeouts."""
    req = Request(url, headers={"User-Agent": "Mozilla/5.0"})
    attempt = 0
    while True:
        try:
            with urlopen(req, timeout=timeout) as r:
                raw = r.read().decode("utf-8", errors="replace")
                return json.loads(raw)
        except HTTPError as e:
            attempt += 1
            if attempt <= max_retries and _is_retryable_http(e.code):
                sleep_s = base_sleep * (2 ** (attempt - 1))
                warn(f"HTTP {e.code} retryable; sleeping {sleep_s:.1f}s (attempt {attempt}/{max_retries})")
                time.sleep(sleep_s)
                continue
            # best-effort body snippet
            body = ""
            try:
                body = e.read().decode("utf-8", errors="replace")[:500].replace("\n", " ")
            except Exception:
                pass
            raise RuntimeError(f"HTTPError {e.code}: {e.reason}. Body: {body}")
        except (URLError, TimeoutError) as e:
            attempt += 1
            if attempt <= max_retries:
                sleep_s = base_sleep * (2 ** (attempt - 1))
                warn(f"Network/timeout retry; sleeping {sleep_s:.1f}s (attempt {attempt}/{max_retries}) -> {e}")
                time.sleep(sleep_s)
                continue
            raise RuntimeError(f"Network/timeout error after retries: {e}")

def zfill_geoid(state: str, county: str, tract: str) -> str:
    return str(state).zfill(2) + str(county).zfill(3) + str(tract).zfill(6)

def to_float(x: str) -> Optional[float]:
    if x is None:
        return None
    x = str(x).strip()
    if x in SENTINELS:
        return None
    try:
        return float(x)
    except Exception:
        return None

def safe_rate(num: Optional[float], den: Optional[float]) -> Optional[float]:
    if num is None or den is None or den == 0:
        return None
    return num / den

@dataclass
class RunResult:
    rows_written: int
    failed_states: List[str]
    output_csv: str
    manifest_json: str

def write_manifest(path: str, payload: dict) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)

def run_acs_pull(
    *,
    year: int,
    var_codes: List[str],
    out_csv: str,
    derived: bool,
    sleep_between_states: float,
    api_key: Optional[str],
    max_states: Optional[int] = None,
) -> RunResult:
    """
    Downloads ACS 5-year tract-level data for given var_codes (US-wide) and writes a single CSV.
    IMPORTANT: we do NOT request state/county/tract inside get=.
    """
    base = f"https://api.census.gov/data/{year}/acs/acs5"
    get_vars = ",".join(["NAME"] + var_codes)

    states = [f"{i:02d}" for i in range(1, 57)]  # 01..56
    if max_states:
        states = states[:max_states]

    # Prepare output (overwrite)
    os.makedirs(os.path.dirname(out_csv) or ".", exist_ok=True)
    if os.path.exists(out_csv):
        os.remove(out_csv)

    failed: List[str] = []
    wrote_header = False
    total = 0

    # Derived column names
    derived_cols = []
    if derived:
        derived_cols = ["poverty_rate", "no_vehicle_rate", "unemployment_rate", "college_plus_rate"]

    for st in states:
        params = {
            "get": get_vars,
            "for": "tract:*",
            "in": f"state:{st} county:*",
        }
        if api_key:
            params["key"] = api_key
        url = base + "?" + urlencode(params)

        try:
            data = fetch_json_with_retries(url)
        except Exception as e:
            warn(f"state={st} FAILED: {e}")
            failed.append(st)
            continue

        if not data or len(data) < 2:
            warn(f"state={st} returned no rows; skipping")
            continue

        header = data[0]  # includes NAME + vars + state/county/tract (returned automatically)
        rows = data[1:]

        # Build final header once
        if not wrote_header:
            final_header = ["GEOID"] + header + derived_cols
            with open(out_csv, "w", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                w.writerow(final_header)
            wrote_header = True

        # Identify indexes needed for derived rates
        idx = {name: header.index(name) for name in header if name in header}
        def hix(col: str) -> Optional[int]:
            return idx.get(col)

        # Write rows (append)
        with open(out_csv, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            for r in rows:
                # API returns state/county/tract at end; but we locate by name to be safe
                state = r[hix("state")] if hix("state") is not None else st
                county = r[hix("county")] if hix("county") is not None else ""
                tract = r[hix("tract")] if hix("tract") is not None else ""
                geoid = zfill_geoid(state, county, tract)

                out_row = [geoid] + r

                if derived:
                    # poverty_rate = B17001_002E / B17001_001E
                    p_den = to_float(r[hix("B17001_001E")]) if hix("B17001_001E") is not None else None
                    p_num = to_float(r[hix("B17001_002E")]) if hix("B17001_002E") is not None else None
                    poverty_rate = safe_rate(p_num, p_den)

                    # no_vehicle_rate = B08201_002E / B08201_001E
                    v_den = to_float(r[hix("B08201_001E")]) if hix("B08201_001E") is not None else None
                    v_num = to_float(r[hix("B08201_002E")]) if hix("B08201_002E") is not None else None
                    no_vehicle_rate = safe_rate(v_num, v_den)

                    # unemployment_rate = B23025_005E / B23025_003E
                    u_den = to_float(r[hix("B23025_003E")]) if hix("B23025_003E") is not None else None
                    u_num = to_float(r[hix("B23025_005E")]) if hix("B23025_005E") is not None else None
                    unemployment_rate = safe_rate(u_num, u_den)

                    # college_plus_rate = (022+023+024+025) / 001
                    e_den = to_float(r[hix("B15003_001E")]) if hix("B15003_001E") is not None else None
                    e_sum = 0.0
                    e_any = False
                    for c in ["B15003_022E", "B15003_023E", "B15003_024E", "B15003_025E"]:
                        ix = hix(c)
                        if ix is None:
                            continue
                        val = to_float(r[ix])
                        if val is None:
                            continue
                        e_sum += val
                        e_any = True
                    college_plus_rate = safe_rate(e_sum if e_any else None, e_den)

                    def fmt(x: Optional[float]) -> str:
                        return "" if x is None else f"{x:.6f}"
                    out_row += [fmt(poverty_rate), fmt(no_vehicle_rate), fmt(unemployment_rate), fmt(college_plus_rate)]

                w.writerow(out_row)
                total += 1

        info(f"state={st} rows={len(rows)} total_written={total}")
        time.sleep(sleep_between_states)

    if not wrote_header:
        die("No data written. Check network, year endpoint, or API key / rate limits.")

    manifest_path = os.path.splitext(out_csv)[0] + "__manifest.json"
    payload = {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "acs_year": year,
        "variable_codes": var_codes,
        "derived_columns": derived_cols,
        "rows_written": total,
        "failed_states": failed,
        "output_csv": os.path.abspath(out_csv),
    }
    write_manifest(manifest_path, payload)
    ok(f"Wrote manifest: {manifest_path}")

    return RunResult(rows_written=total, failed_states=failed, output_csv=os.path.abspath(out_csv), manifest_json=os.path.abspath(manifest_path))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--year", type=int, default=2022)
    ap.add_argument("--out", default=None, help="Output CSV path (default: ./ACS_Model4_FullControls_<YEAR>.csv)")
    ap.add_argument("--sleep", type=float, default=0.20, help="Sleep between states (seconds)")
    ap.add_argument("--max-states", type=int, default=None, help="Debug: limit number of states")
    args = ap.parse_args()

    api_key = os.environ.get("CENSUS_API_KEY", "").strip() or None
    year = args.year
    out_csv = args.out or f"ACS_Model4_FullControls_{year}.csv"

    var_codes = ["B19013_001E", "B17001_001E", "B17001_002E", "B08201_001E", "B08201_002E", "B23025_003E", "B23025_005E", "B15003_001E", "B15003_022E", "B15003_023E", "B15003_024E", "B15003_025E", "B01003_001E"]

    info(f"Model 4 pull starting (ACS {year})")
    res = run_acs_pull(
        year=year,
        var_codes=var_codes,
        out_csv=out_csv,
        derived=True,
        sleep_between_states=args.sleep,
        api_key=api_key,
        max_states=args.max_states,
    )
    ok(f"Done. Rows={res.rows_written}. Output={res.output_csv}")
    if res.failed_states:
        warn(f"Failed states: {res.failed_states}")

if __name__ == "__main__":
    main()
