r"""
acs_pull_model1.py

Model 1 uses NO ACS controls (baseline uses only outcome + distance-only access elsewhere).
This script exists for symmetry and produces a tiny manifest so your pipeline stays consistent.

Run:
  py acs_pull_model1.py
"""

from __future__ import annotations
import json, os, time

def main():
    out = "ACS_MODEL1_NO_PULL__manifest.json"
    payload = {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "model": "Model 1",
        "acs_needed": False,
        "note": "Model 1 uses no ACS controls. Use PLACES + USDA only.",
    }
    with open(out, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    print(f"✅ Model 1: no ACS pull required. Wrote {os.path.abspath(out)}")

if __name__ == "__main__":
    main()
