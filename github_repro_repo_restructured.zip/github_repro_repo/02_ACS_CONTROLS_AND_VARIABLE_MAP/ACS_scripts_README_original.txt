ACS model scripts (4 scripts)

These scripts download ACS 5-year tract covariates via Census API.
Recommended: set your API key before running:

  set CENSUS_API_KEY=YOUR_KEY_HERE

Scripts:
- acs_pull_model1.py               (Model 1: no ACS pull; writes a manifest)
- acs_pull_model2_controls.py      (Model 2 controls)
- acs_pull_model3_index_inputs.py  (Model 3 index inputs)
- acs_pull_model4_full_controls.py (Model 4, adds optional population)

Run examples:
  py acs_pull_model2_controls.py --year 2022
  py acs_pull_model3_index_inputs.py --year 2022
  py acs_pull_model4_full_controls.py --year 2022

Notes:
- Do NOT include state/county/tract in `get=` (scripts already enforce this).
- Derived columns are computed in the output CSV:
  poverty_rate, no_vehicle_rate, unemployment_rate, college_plus_rate
- Sentinel values (-666666666, -888888888, -999999999) are treated as missing.
