# Mini-PhD Reproducibility Pack (Logic + Run Order)

## What this repository is

This repository is a **reproducibility logic pack** for the Mini-PhD project on obesity, distance-only food access, and broader effective access.

It is designed to let another person reconstruct the workflow in the same order it was actually carried out.

It preserves:
- the raw-data acquisition logic,
- the ACS pull logic,
- the variable-selection logic,
- the country-selection logic,
- the model-run prompts,
- and the descriptive/Australia utility scripts and prompts.

It does **not** include all raw, intermediate, or final output files. See `07_NOTES_AND_LIMITS/REPOSITORY_SCOPE_AND_LIMITS.txt`.

---

## High-level workflow (actual order of operations)

1. **Acquire U.S. raw data**
   - CDC PLACES tract obesity (manual download because the file was too large for chat upload in one piece)
   - USDA Food Access Research Atlas (downloaded with a Python script)
   - ACS tract controls (downloaded via Census API scripts)

2. **Split oversized files when needed**
   - large CSVs were split so they could be uploaded/handled in smaller chunks

3. **Use the U.S. data to run Models 1–4**
   - Model 1: CDC + USDA
   - Model 2: CDC + USDA + ACS controls
   - Model 3: CDC + ACS broader-access specification
   - Model 4: CDC + USDA + ACS broader-access specification together

4. **Evaluate second-country options**
   - compare Australia, Canada, and UK/England
   - select Australia as the preferred second case

5. **Acquire and build the Australia dataset**
   - reconstruct the analysis-ready LGA file via prompt-guided workflow

6. **Run the Australia comparative regressions**
   - generate the Australia table(s) and figure(s)

7. **Generate descriptive tables and figures**
   - section 5.1 tables/figures
   - model-specific tables/figures
   - Australia comparative tables/figures

---

## Folder guide

### `00_START_HERE`
Master walkthrough files.

### `01_US_DATA_ACQUISITION`
Files for reacquiring the U.S. raw inputs.
- `download_usda_food_access_atlas.py`
- `PLACES_manual_download_note.txt`
- `README_original_pack.txt`

### `02_ACS_CONTROLS_AND_VARIABLE_MAP`
Files for planning and pulling ACS variables.
- ACS pull scripts for Models 1–4
- variable-map / ACS-pull prompt
- ACS failed-messages note
- original ACS README

### `03_PREPROCESSING_AND_FILE_SPLITTING`
Utility for splitting oversized CSV files when needed.
- `split_csv_3_parts.py`
- `prompt_for_csv_splitter.txt`

### `04_MODEL_RUN_PROMPTS`
Prompts for reproducing the U.S. model sequence.
- `model_1_to_4_regression_prompts.txt`
- `model_1_to_4_regression_prompts_data_outputs_only.txt`
- `MODEL_RUNS_NOTE.txt`

### `05_AUSTRALIA_BUILD_AND_RESULTS`
Files for the Australia build and Australia result reproduction.
- `australia_data_reconstruction_prompt.txt`
- `australia_regressions_tables_figures_prompt.txt`
- `descriptive_stats_remaining_tables_figures.py`

### `06_COUNTRY_SELECTION_AND_BENCHMARKING`
Files for the second-country comparison stage.
- `country_comparison_canada_uk_australia_prompt.txt`
- `uk_manual_data_acquisition_prompt.txt`

### `07_NOTES_AND_LIMITS`
Important repository-scope notes.
- `REPOSITORY_SCOPE_AND_LIMITS.txt`

---

## Minimum files a third party must obtain before rerunning

### U.S.
- CDC PLACES tract obesity CSV(s)
- USDA Food Access Research Atlas workbook
- ACS output CSVs for the models being rerun

### Australia
- raw PHIDU workbook / notes / backup deprivation file OR the rebuilt Australia analysis-ready file

### UK / Canada benchmark stage
- only needed if the third party wants to recreate the country-selection stage

---

## Recommended rerun order

### Step 1 — Reacquire U.S. raw inputs
Start in `01_US_DATA_ACQUISITION`.

1. Use `download_usda_food_access_atlas.py` to get the USDA workbook.
2. Use `PLACES_manual_download_note.txt` to download CDC PLACES manually.
3. Save the files with stable names.

### Step 2 — Plan ACS variable pulls
Go to `02_ACS_CONTROLS_AND_VARIABLE_MAP`.

1. Read `model_variable_map_and_acs_pull_prompt.txt`.
2. Confirm which ACS variables are needed for Models 2–4.
3. Use the ACS pull scripts to fetch the needed data.

### Step 3 — Split large files if needed
If a file is too large for your environment:
1. go to `03_PREPROCESSING_AND_FILE_SPLITTING`
2. run `split_csv_3_parts.py`
3. keep the naming consistent

### Step 4 — Recreate U.S. models
Go to `04_MODEL_RUN_PROMPTS`.

1. Use the model prompts to regenerate local analysis scripts.
2. Run Model 1 first, then 2, then 3, then 4.
3. Export:
   - analytic sample CSVs
   - regression result CSVs
   - figure PNGs
   - figure-data CSVs

### Step 5 — Recreate second-country selection logic
If needed, go to `06_COUNTRY_SELECTION_AND_BENCHMARKING`.

1. Use `country_comparison_canada_uk_australia_prompt.txt`
2. If the UK benchmark is being recreated, use `uk_manual_data_acquisition_prompt.txt`

### Step 6 — Rebuild Australia
Go to `05_AUSTRALIA_BUILD_AND_RESULTS`.

1. Use `australia_data_reconstruction_prompt.txt` to recreate the analysis-ready LGA file
2. Use `australia_regressions_tables_figures_prompt.txt` to rerun the Australia regressions and regenerate the tables/figures

### Step 7 — Rebuild descriptive tables and figures
Still in `05_AUSTRALIA_BUILD_AND_RESULTS`:
1. run `descriptive_stats_remaining_tables_figures.py`
2. export Table 1, Table 2, and Figures 1–4

---

## Important cautions

- **Do not exclude Arkansas** in ACS-based U.S. runs.
- Treat all tract GEOIDs as **zero-padded 11-character strings**.
- The project uses a **measurement-validity** framing, not a causal-policy framing.
- For Model 3 and Model 4, be careful about **double-counting** if a composite effective-access index is used.
- Australia is a **directional comparative case**, not a perfectly harmonized second main case.

---

## What should be added later if desired

This repo could be made even stronger by later adding:
- a final folder tree for raw/intermediate/output placeholders,
- a short checklist of expected filenames per step,
- and locally regenerated outputs for QA only (if file size allows).

