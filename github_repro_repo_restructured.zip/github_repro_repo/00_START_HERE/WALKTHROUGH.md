Detailed Walkthrough
====================

This document explains the workflow in the same order it actually happened.

1) U.S. raw acquisition
-----------------------
The U.S. base was assembled from three source families:

- CDC PLACES tract obesity
  - acquired manually from the website because the file was too large to handle comfortably in one piece
- USDA Food Access Research Atlas
  - acquired with a Python script
- ACS tract controls
  - acquired via Census API scripts for the models that needed them

Files to start with:
- `01_US_DATA_ACQUISITION/download_usda_food_access_atlas.py`
- `01_US_DATA_ACQUISITION/PLACES_manual_download_note.txt`
- `02_ACS_CONTROLS_AND_VARIABLE_MAP/acs_pull_model*.py`

2) Large-file splitting
-----------------------
Some files were too large for chat-based handling.
When that happened, they were split into smaller chunks.

Use:
- `03_PREPROCESSING_AND_FILE_SPLITTING/split_csv_3_parts.py`

3) Variable planning for the U.S. models
----------------------------------------
Before running Models 2–4, the ACS pull had to be constrained to only the variables that the models actually used.
That planning logic is preserved in:

- `02_ACS_CONTROLS_AND_VARIABLE_MAP/model_variable_map_and_acs_pull_prompt.txt`

4) U.S. model sequence
----------------------
The actual U.S. model sequence was:

- Model 1:
  obesity ~ distance-only access

- Model 2:
  obesity ~ distance-only access + structural controls

- Model 3:
  obesity ~ broader effective-access specification
  (both a separate-variable sensitivity version and a preferred composite-index version)

- Model 4:
  obesity ~ distance-only access + broader effective-access index

The exact internal code used in chat is not preserved, but the prompts needed to regenerate the run logic are preserved in:
- `04_MODEL_RUN_PROMPTS/`

5) Second-country selection
---------------------------
A second-country comparison was considered.
The candidates were:
- Australia
- Canada
- UK / England

That comparison logic is preserved in:
- `06_COUNTRY_SELECTION_AND_BENCHMARKING/country_comparison_canada_uk_australia_prompt.txt`

6) Australia build
------------------
Australia was selected as the preferred second case.
The analysis-ready Australia file was created via a prompt-guided workflow that extracted:
- adult obesity
- no-motor-vehicle
- IRSD

from the PHIDU / SEIFA source family.

That logic is preserved in:
- `05_AUSTRALIA_BUILD_AND_RESULTS/australia_data_reconstruction_prompt.txt`

7) Australia regressions
------------------------
The Australia comparative results were then estimated separately.
The prompt to reproduce the Australia tables and figures is in:
- `05_AUSTRALIA_BUILD_AND_RESULTS/australia_regressions_tables_figures_prompt.txt`

8) Descriptive tables and figures
---------------------------------
The descriptive-statistics section used:
- Table 1
- Table 2
- Figures 1–4

The script that rebuilds those outputs is:
- `05_AUSTRALIA_BUILD_AND_RESULTS/descriptive_stats_remaining_tables_figures.py`

9) Repository philosophy
------------------------
This repository does not pretend to be a complete raw-data archive.
Its purpose is to preserve:
- the logic,
- the order of operations,
- the acquisition path,
- and the prompts/scripts needed to regenerate the evidence.

See also:
- `07_NOTES_AND_LIMITS/REPOSITORY_SCOPE_AND_LIMITS.txt`
