import csv
import math
import sys
from pathlib import Path

NUM_SPLITS = 3


def find_single_csv_file(directory: Path) -> Path:
    files = [f for f in directory.iterdir() if f.is_file() and f.suffix.lower() == ".csv"]

    # Ignore files already created by this script
    files = [f for f in files if not any(part in f.stem for part in ["_part1", "_part2", "_part3"])]

    if len(files) == 0:
        raise FileNotFoundError("No CSV file found in the current directory.")

    if len(files) > 1:
        names = "\n".join(f" - {f.name}" for f in files)
        raise RuntimeError(
            "More than one CSV file found in the current directory.\n"
            "Please keep only one main CSV file in the folder.\n"
            f"Found:\n{names}"
        )

    return files[0]


def main():
    current_dir = Path.cwd()

    try:
        input_path = find_single_csv_file(current_dir)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

    with open(input_path, "r", newline="", encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        rows = list(reader)

    if not rows:
        print("Error: CSV file is empty.")
        sys.exit(1)

    header = rows[0]
    data_rows = rows[1:]

    total_data_rows = len(data_rows)
    chunk_size = math.ceil(total_data_rows / NUM_SPLITS) if total_data_rows > 0 else 0

    stem = input_path.stem
    suffix = input_path.suffix
    output_dir = input_path.parent

    print(f"Input file: {input_path.name}")
    print(f"Total data rows: {total_data_rows}")
    print(f"Chunk size: {chunk_size}")
    print()

    for i in range(NUM_SPLITS):
        start = i * chunk_size
        end = min((i + 1) * chunk_size, total_data_rows)
        chunk = data_rows[start:end]

        output_path = output_dir / f"{stem}_part{i + 1}{suffix}"

        with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f)
            writer.writerow(header)
            writer.writerows(chunk)

        print(f"Created: {output_path.name} ({len(chunk)} data rows)")

    print("\nDone.")


if __name__ == "__main__":
    main()
